﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using NUnit.Framework;


namespace ObjectPageModelProj
{
    public class Inventory: BaseClass
    {
        string actualText = "Your Cart";
        public void AddtoCard()
        {
            dr.FindElement(By.Id(Locator.AddtoCartId)).Click();
        }
        public void Checkout1()
        {
            dr.FindElement(By.XPath(Locator.CheckoutButton)).Click();
        }

        public void Validate()
        {
            Assert.AreEqual(dr.FindElement(By.XPath(Locator.CheckoutText)).Text, actualText);
        }

        string pageText = "Checkout: Your Information";
        string OverViewPageText = "Checkout: Overview";
        string CheckoutComplete = "Thank you for your order!";
        public void CheckOut2()
        {
            dr.FindElement(By.XPath(Locator.CheckOutButton)).Click();
        }

        public void FillInfo(string firstName, string lastName, string zip)
        {
            dr.FindElement(By.XPath(Locator.FirstName)).SendKeys(firstName);
            dr.FindElement(By.XPath(Locator.LastName)).SendKeys(lastName);
            dr.FindElement(By.XPath(Locator.Zip)).SendKeys(zip);
            dr.FindElement(By.XPath(Locator.ContinueButton)).Click();
        }

        public void Validate2()
        {
            string CheckoutInfoPageText = dr.FindElement(By.XPath(Locator.CheckoutInfoPage)).Text;
            Assert.AreEqual(pageText, CheckoutInfoPageText);
        }

        public void Validate3()
        {
            string CheckoutOverviewPageText = dr.FindElement(By.XPath(Locator.CheckoutOverviewPage)).Text;
            Assert.AreEqual(OverViewPageText, CheckoutOverviewPageText);
        }

        public void FinishOrder()
        {
            dr.FindElement(By.XPath(Locator.FinishOrder)).Click();
        }

        public void Validate4()
        {
            string CheckoutCompleteText = dr.FindElement(By.XPath(Locator.CheckoutComplete)).Text;
            Assert.AreEqual(CheckoutComplete, CheckoutCompleteText);
        }

    }
}
