﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using NUnit.Framework;

namespace ObjectPageModelProj
{
    public class Login : BaseClass
    {
        string actualText = "Products";
        public void LoginHelper(string user, string passowrd)
        {
            dr.FindElement(By.Id(Locator.UserName)).SendKeys(user);
            dr.FindElement(By.Id(Locator.Password)).SendKeys(passowrd);
            dr.FindElement(By.Id(Locator.Login)).Click();
        }

        public void SuccessfullMessageValidation()
        {
            string validationText = dr.FindElement(By.XPath(Locator.ProductText)).Text;
            Assert.AreEqual(actualText, validationText);
        }
    }
}
