﻿using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;

namespace ObjectPageModelProj
{
    public class LoginTestClasss
    {
        Login LoginPC = new Login();
        Inventory InventoryPC = new Inventory();

        [Test]
        public void LoginTest()
        {
            LoginPC.DriverIni();
            LoginPC.OpenBrower();
            LoginPC.LoginHelper("standard_user", "secret_sauce");
            //LoginPC.SuccessfullMessageValidation();
        }
 
        [Test]
        public void AddtocartAndCheckout()
        {
            LoginTest();
            InventoryPC.AddtoCard();
            InventoryPC.Checkout1();
            InventoryPC.Validate();
            InventoryPC.CheckOut2();
            InventoryPC.Validate2();
            InventoryPC.FillInfo("ABC","XYZ","123");
            InventoryPC.Validate3();
            InventoryPC.FinishOrder();
            InventoryPC.Validate4();
            InventoryPC.CloseBrower();

        }

    }
}
