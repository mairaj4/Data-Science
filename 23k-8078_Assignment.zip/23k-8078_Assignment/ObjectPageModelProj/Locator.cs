﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ObjectPageModelProj
{
    public static class Locator
    {
        public const string UserName = "user-name";
        public const string Password = "password";
        public const string Login = "login-button";
        public const string ProductText = "//div[@id='']";
        public const string AddtoCartId = "add-to-cart-sauce-labs-backpack";
        public const string CheckoutButton = "//span[contains(text(),'1')]";
        public const string CheckoutText = "//span[@class='title']";
        public const string CartText = "//span[@class='title']";
        public const string CheckOutButton = "//button[@id='checkout']";
        public const string FirstName = "//input[@id='first-name']";
        public const string LastName = "//input[@id='last-name']";
        public const string Zip = "//input[@id='postal-code']";
        public const string CheckoutInfoPage = "//span[@class='title']";
        public const string ContinueButton = "//input[@id='continue']";
        public const string CheckoutOverviewPage = "//span[@class='title']";
        public const string FinishOrder = "//button[@id='finish']";
        public const string CheckoutComplete = "//h2[normalize-space()='Thank you for your order!']";



    }
}
