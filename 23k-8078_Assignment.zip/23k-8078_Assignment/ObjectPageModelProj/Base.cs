﻿using System;
using System.Collections.Generic;
using System.Text;
using OpenQA.Selenium.Chrome;

namespace ObjectPageModelProj
{
    public class BaseClass
    {
        public static ChromeDriver dr;
        public string url = "https://www.saucedemo.com/";

        public void DriverIni()
        {
            dr = new ChromeDriver();
        }

        public void OpenBrower()
        {
            dr.Manage().Window.Maximize();
            dr.Navigate().GoToUrl(url);
        }

        public void CloseBrower()
        {
            dr.Close();
            dr.Dispose();
        }

    }
}
