using System;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using NUnit.Framework;


namespace SwagLab_BDD.StepDefinitions
{
    [Binding]
    public class ValidateTheSuccessfullLoginInSwagLabStepDefinitions
    {
        ChromeDriver driver = new ChromeDriver();
        string url;
        [Given(@"Go to the URL https://www\.saucedemo\.com/")]
        public void GivenGoToTheURLHttpsWww_Saucedemo_Com()
        {
            driver.Manage().Window.Maximize();
            driver.Navigate().GoToUrl("https://www.saucedemo.com/");
        }

        [Given(@"Enter user name")]
        public void GivenEnterUserName()
        {
            driver.FindElement(By.Id("user-name")).SendKeys("standard_user");
        }

        [Given(@"Enter password")]
        public void GivenEnterPassword()
        {
            driver.FindElement(By.Id("password")).SendKeys("secret_sauce");
        }

        [When(@"Click login button for successfull Login")]
        public void WhenClickLoginButtonForSuccessfullLogin()
        {
            driver.FindElement(By.Id("login-button")).Click();
        }

        [Then(@"User logged in successfully")]
        public void ThenUserLoggedInSuccessfully()
        {
            string text = driver.FindElement(By.XPath("//input[@id='login-button']")).Text;
            Assert.AreEqual("Products", text);
        }
    }
}
