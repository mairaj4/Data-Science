﻿using Newtonsoft.Json.Linq;
using NUnit.Framework;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BDD_SEl_POM_JSON_Allure
{
    public class LoginPageClass : BaseClass
    {

        public void LoginMethod()
        {
            var jsonData = JObject.Parse(File.ReadAllText("D:\\DATA 11-1-2023\\FAST_NU_FAll_2022\\BDD_POM_JSON\\BDD_POM_JSON\\Data.json"));
            string url = jsonData["url"].ToString();
            string userName = jsonData["username"].ToString();
            string password = jsonData["password"].ToString();
            chromeDriver.FindElement(By.Id(Locators.UserName)).SendKeys(userName);
            chromeDriver.FindElement(By.Id(Locators.Password)).SendKeys(password);
            chromeDriver.FindElement(By.Id(Locators.LoginButton)).Click();

        }

        public void ValidateSuccessfullLogin()
        {
            var jsonData = JObject.Parse(File.ReadAllText("D:\\DATA 11-1-2023\\FAST_NU_FAll_2022\\BDD_SEl_POM_JSON_Allure\\BDD_SEl_POM_JSON_Allure\\data.json"));
            string url = jsonData["url"].ToString();
            string productText = jsonData["producttext"].ToString();
            string text = chromeDriver.FindElement(By.XPath(Locators.ExpectedProdcutTextLocator)).Text;
            Assert.AreEqual(text, productText);
        }


        public void ValidateUnsuccessssulLogin()
        {
            string expectedMessage = "Epic sadface: Username and password do not match any user in this service";
            string notLoginMessage = chromeDriver.FindElement(By.XPath(Locators.NotLoginMessage)).Text;
            Assert.AreEqual(notLoginMessage, expectedMessage);
        }
    }
}