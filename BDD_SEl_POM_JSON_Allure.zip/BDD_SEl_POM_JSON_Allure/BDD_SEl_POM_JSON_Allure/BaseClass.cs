﻿using Newtonsoft.Json.Linq;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BDD_SEl_POM_JSON_Allure
{
    public class BaseClass
    {
        /// <summary>
        /// Chrome Driver initialization
        /// </summary>
        public static ChromeDriver chromeDriver;
        //public string url = "https://www.saucedemo.com/";

        /// <summary>
        /// Chrome Driver function
        /// </summary>
        public void DriverInitiliaze()
        {
            chromeDriver = new ChromeDriver();
        }

        public void CloseDriver()
        {
            chromeDriver.Close();
        }

        public void OpenChromeWindow()
        {
            var jsonData = JObject.Parse(File.ReadAllText("D:\\DATA 11-1-2023\\FAST_NU_FAll_2022\\BDD_POM_JSON\\BDD_POM_JSON\\Data.json"));
            string url = jsonData["url"].ToString();
            chromeDriver.Manage().Window.Maximize();
            chromeDriver.Navigate().GoToUrl(url);

        }
    }
}
