using System;
using TechTalk.SpecFlow;

namespace BDD_SEl_POM_JSON_Allure
{
    [Binding]
    public class ToValidateTheLoginScenarioWithValidUserAndPasswordStepDefinitions
    {
        LoginPageClass loginPageClass = new LoginPageClass();
        [Given(@"Open Browser and goto the url")]
        public void GivenOpenBrowserAndGotoTheUrl()
        {
            loginPageClass.DriverInitiliaze();
            loginPageClass.OpenChromeWindow();
            
        }

        [When(@"Enter valid User and passord")]
        public void WhenEnterValidUserAndPassord()
        {
            loginPageClass.ValidateSuccessfullLogin();
        }

        [Then(@"user should be logged in")]
        public void ThenUserShouldBeLoggedIn()
        {
            loginPageClass.CloseDriver();
        }
    }
}
