﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;


namespace SwagLab_AST_FAST_POM
{
    public class LoginPageClass :BaseClass
    {
        string actualText = "Products";
        public void LoginHelper(string user, string passcode)
        {
            chromeDriver.FindElement(By.Id(Locators.UserName)).SendKeys(user);
            chromeDriver.FindElement(By.Id(Locators.Password)).SendKeys(passcode);
            chromeDriver.FindElement(By.Id(Locators.Login)).Click();

        }

        public void SuccessfullMessageValidation()
        {
            string validationText = chromeDriver.FindElement(By.XPath(Locators.ProductText)).Text;
            Assert.AreEqual(actualText, validationText);
        }
    }
}
