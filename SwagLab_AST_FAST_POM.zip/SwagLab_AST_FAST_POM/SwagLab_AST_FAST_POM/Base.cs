﻿using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwagLab_AST_FAST_POM
{
    public class BaseClass
    {
        public static ChromeDriver chromeDriver;
        public string url = "https://www.saucedemo.com/";

        /// <summary>
        /// Chrome Driver Initilaize
        /// </summary>
        public void DriverInitialize()

        {
            chromeDriver = new ChromeDriver();

        }

        public void CloseBrowserInsitance()
        {
            chromeDriver.Close();
            chromeDriver.Dispose();
        }

        public void OpenBrowserAndUrl()
        {
            chromeDriver.Manage().Window.Maximize();
            chromeDriver.Navigate().GoToUrl(url);

        }

    }
}
