﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwagLab_AST_FAST_POM
{
    public static class Locators
    {
        public const string UserName = "user-name";
        public const string Password = "password";
        public const string Login = "password";
        public const string  ProductText = "password";
        public const string BagPackProduct = "add-to-cart-sauce-labs-backpack";
        public const string CartLink = "//a[@class='shopping_cart_link']";
    }
}
