﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwagLab_AST_FAST_POM
{
    public class LoginTestCases
    {
        LoginPageClass loginPageClass = new LoginPageClass();

        public void LoginTest1()
        {
            loginPageClass.DriverInitialize();
            loginPageClass.OpenBrowserAndUrl();
            loginPageClass.LoginHelper("standard_user", "secret_sauce");
            loginPageClass.SuccessfullMessageValidation();

        }
    }
}
