namespace SwagLab_AST_FAST_POM
{
    public class Tests
    {
        
        [Test]
        public void Test1()
        {
            Assert.Pass();
        }
    }
}